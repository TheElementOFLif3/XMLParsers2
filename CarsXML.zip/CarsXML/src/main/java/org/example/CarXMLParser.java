package org.example;

import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.io.*;
import java.util.Scanner;

public class CarXMLParser {
    public static void main(String[] args) {
        String filename = "src/main/cars.xml"; // Change the path to your cars.xml file

        try {
            File inputFile = new File(filename);
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(inputFile);
            document.getDocumentElement().normalize();

            Scanner scanner = new Scanner(System.in);

            while (true) {
                displayMenu();
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume the newline character after reading the choice

                switch (choice) {
                    case 1:
                        System.out.print("Enter the manufacturer: ");
                        String manufacturer = scanner.nextLine();
                        filterCarsByManufacturer(document, manufacturer);
                        break;
                    case 2:
                        System.out.print("Enter the start year: ");
                        int startYear = scanner.nextInt();
                        System.out.print("Enter the end year: ");
                        int endYear = scanner.nextInt();
                        filterCarsByYearRange(document, startYear, endYear);
                        break;
                    case 3:
                        filterCarsByFuelType(document, scanner);
                        break;
                    case 4:
                        System.out.println("Exiting the program...");
                        System.exit(0);
                    default:
                        System.out.println("Invalid choice! Please try again.");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void displayMenu() {
        System.out.println("**************************************");
        System.out.println("                MENU");
        System.out.println("**************************************");
        System.out.println("1. Filter cars by manufacturer");
        System.out.println("2. Filter cars by year range");
        System.out.println("3. Filter cars by fuel type");
        System.out.println("4. Exit");
        System.out.print("Enter your choice: ");
    }

    private static void filterCarsByManufacturer(Document document, String manufacturer) {
        NodeList carList = document.getElementsByTagName("car");
        boolean found = false;

        for (int i = 0; i < carList.getLength(); i++) {
            Node carNode = carList.item(i);

            if (carNode.getNodeType() == Node.ELEMENT_NODE) {
                Element carElement = (Element) carNode;
                String carManufacturer = carElement.getElementsByTagName("manufacturer").item(0).getTextContent();

                if (carManufacturer.equalsIgnoreCase(manufacturer)) {
                    displayCarInfo(carElement);
                    found = true;
                }
            }
        }

        if (!found) {
            System.out.println("No cars found for the manufacturer: " + manufacturer);
        }
    }

    private static void filterCarsByYearRange(Document document, int startYear, int endYear) {
        NodeList carList = document.getElementsByTagName("car");
        boolean found = false;

        for (int i = 0; i < carList.getLength(); i++) {
            Node carNode = carList.item(i);

            if (carNode.getNodeType() == Node.ELEMENT_NODE) {
                Element carElement = (Element) carNode;
                int productionYear = Integer.parseInt(carElement.getElementsByTagName("production-year").item(0).getTextContent());

                if (productionYear >= startYear && productionYear <= endYear) {
                    displayCarInfo(carElement);
                    found = true;
                }
            }
        }

        if (!found) {
            System.out.println("No cars found within the specified year range: " + startYear + " - " + endYear);
        }
    }

    private static void filterCarsByFuelType(Document document, Scanner scanner) {
        System.out.print("Enter the fuel type (Electric, Fuel, or Hybrid): ");
        String fuelType = scanner.nextLine();

        if (fuelType.equalsIgnoreCase("Electric") || fuelType.equalsIgnoreCase("Fuel") || fuelType.equalsIgnoreCase("Hybrid")) {
            if (fuelType.equalsIgnoreCase("Fuel") || fuelType.equalsIgnoreCase("Hybrid")) {
                System.out.print("Enter the maximum consumption: ");
                double maxConsumption = scanner.nextDouble();
                scanner.nextLine(); // Consume the newline character after reading the consumption
                filterCarsByFuelTypeAndConsumption(document, fuelType, maxConsumption);
            } else {
                filterCarsByFuelType(document, fuelType);
            }
        } else {
            System.out.println("Invalid fuel type! Please try again.");
        }
    }

    private static void filterCarsByFuelType(Document document, String fuelType) {
        NodeList carList = document.getElementsByTagName("car");
        boolean found = false;

        for (int i = 0; i < carList.getLength(); i++) {
            Node carNode = carList.item(i);

            if (carNode.getNodeType() == Node.ELEMENT_NODE) {
                Element carElement = (Element) carNode;
                Element consumptionElement = (Element) carElement.getElementsByTagName("consumption").item(0);
                String consumptionType = consumptionElement.getAttribute("type");

                if (consumptionType.equalsIgnoreCase(fuelType)) {
                    if (fuelType.equalsIgnoreCase("electric")) {
                        String consumptionValue = consumptionElement.getTextContent();
                        if (consumptionValue.equals("0")) {
                            displayCarInfo(carElement);
                            found = true;
                        }
                    } else {
                        displayCarInfo(carElement);
                        found = true;
                    }
                }
            }
        }

        if (!found) {
            System.out.println("No cars found with the specified fuel type: " + fuelType);
        }
    }

    private static void filterCarsByFuelTypeAndConsumption(Document document, String fuelType, double maxConsumption) {
        NodeList carList = document.getElementsByTagName("car");
        boolean found = false;

        for (int i = 0; i < carList.getLength(); i++) {
            Node carNode = carList.item(i);

            if (carNode.getNodeType() == Node.ELEMENT_NODE) {
                Element carElement = (Element) carNode;
                Element consumptionElement = (Element) carElement.getElementsByTagName("consumption").item(0);
                String consumptionType = consumptionElement.getAttribute("type");

                if (consumptionType.equalsIgnoreCase(fuelType)) {
                    double consumption = Double.parseDouble(consumptionElement.getTextContent());

                    if (consumption <= maxConsumption) {
                        displayCarInfo(carElement);
                        found = true;
                    }
                }
            }
        }

        if (!found) {
            System.out.println("No cars found with the specified fuel type: " + fuelType +
                    " and maximum consumption: " + maxConsumption);
        }
    }

    private static void displayCarInfo(Element carElement) {
        System.out.println("\n**************************************");
        System.out.println("Car ID: " + carElement.getAttribute("id"));
        System.out.println("Manufacturer: " + carElement.getElementsByTagName("manufacturer").item(0).getTextContent());
        System.out.println("Model: " + carElement.getElementsByTagName("model").item(0).getTextContent());
        System.out.println("Production Year: " + carElement.getElementsByTagName("production-year").item(0).getTextContent());
        System.out.println("Horsepower: " + carElement.getElementsByTagName("horsepower").item(0).getTextContent());
        Element consumptionElement = (Element) carElement.getElementsByTagName("consumption").item(0);
        String consumptionType = consumptionElement.getAttribute("type");
        System.out.println("Consumption: " + consumptionElement.getTextContent() + " (Type: " + consumptionType + ")");
        System.out.println("Price: " + carElement.getElementsByTagName("price").item(0).getTextContent());
        System.out.println("**************************************");
    }
}
